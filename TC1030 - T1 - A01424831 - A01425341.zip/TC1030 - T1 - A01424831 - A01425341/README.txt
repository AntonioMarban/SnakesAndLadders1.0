C++ program for creating & simulating a Snake & Ladder Game
Coded by: Antonio Marban Regalado and Carol Jatziry Rendon Guerrero

Instructions and rules:
1. You can place the Snakes and Ladders board on snakes.cpp line 26. 

2. Decide who goes first: You can use any method to determine the first player, such as flipping a coin or rolling a die.
3. Take turns: enter C to continue next turn or E to end the game.

If your are at the base of a ladder, you move 3 positions. If you are on the head of a snake, you must move down 3 positions.
Reach the end: Continue taking turns and moving your game piece until you reach or exceed the final square, which is usually labeled "30." The first player to reach or exceed the final square wins the game.

Winning and penalties: If you land exactly on the final square (30), congratulations! You have won the game. However, if your roll is greater than the number of remaining spaces to reach the final square, the message "the maximum number of turns has been reached".

Remember to have fun and enjoy playing Snakes and Ladders with your friends and family!
